package semant;

public abstract class Frag {
  public Frag next;
}
