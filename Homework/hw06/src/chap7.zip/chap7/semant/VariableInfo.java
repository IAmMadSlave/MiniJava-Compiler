package semant;

class VariableInfo {
	
  syntaxtree.Type type;
  frame.Access access;
	    
  public VariableInfo(syntaxtree.Type t) {
    type = t;
  }
}
