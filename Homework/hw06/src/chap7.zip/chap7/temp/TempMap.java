package temp;

public interface TempMap {public String tempMap(Temp t);}

