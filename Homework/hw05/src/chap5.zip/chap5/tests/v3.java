class Foo {									// [10a] 
  public static void main(String[] a) {
    System.out.println(new Bar().f(3));
  }
}

class Bar {
  int c;

  public int f(int a) {
    int b;
    boolean x;

  if (b+4) {b=b+7;}
  else {b=3;}

  return b+5;
  }

  public int g(int a) {
	return a+12;
  }
}

