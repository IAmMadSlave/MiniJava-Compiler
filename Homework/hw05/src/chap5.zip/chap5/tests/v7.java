class Foo {										// [15] [16] [17] [18]
  public static void main(String[] a) {
    System.out.println(new Bar().f(3));
  }
}

class Bar {
  int c;

  public int f(int a) {
    int b;
    int[] c;
    boolean x;


    x[b]  = 4;
    ff[b] = 4;
    c[x]  = 4;
    c[b]  = x;


  while (b<4) {System.out.println(b);}

  return b+5;
  }

  public int g(int a) {
	return a+12;
  }
}

