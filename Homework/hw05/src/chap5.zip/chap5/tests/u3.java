class Foo {
  public static void main(String[] a) {
    System.out.println(new Bar().f(3));
  }
}

class Bar {
  int c;
  boolean c;

  public int f(int a) {
    int b;
    boolean x;


    return b+7;
  }
}

