class Foo {										// [32] [33] [34]
  public static void main(String[] a) {
    System.out.println(new Bar().f(4));
  }
}
class Bar {
  int f;

  public int f(int d) {
  	boolean x;
	booleans y;
	int b;
	int e;
    int[] c;


	c = new int[x];
	x = !b;

    return b+5;
  }

  public int g(int a) {
	return a+12;
  }
}

