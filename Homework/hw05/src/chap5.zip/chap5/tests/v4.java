class Foo {									// [11] 
  public static void main(String[] a) {
    System.out.println(new Bar().f(3));
  }
}

class Bar {
  int c;

  public int f(int a) {
    int b;
    boolean x;

  while (b+4) {b=b+7;}

  return b+5;
  }

  public int g(int a) {
	return a+12;
  }
}

