class Foo {										// [26] 
  public static void main(String[] a) {
    System.out.println(new Bar().f(3));
  }
}

class Bar {
  int f;

  public int f(int d) {
    int a;
    int b;
    int c;
    int[] e;
    boolean x;
    boolean y;
    boolean z;

    a = b.length;
    
    
    while (b<4) {System.out.println(b);}

    return b+5;
  }

  public int g(int a) {
	return a+12;
  }
}

